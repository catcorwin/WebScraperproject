import wikipedia
#import datetime
import requests
from bs4 import BeautifulSoup
print("Hello, welcome to my Webscrapper.  This webscrapper utilizes wikipedia and can only gather data from wikipedia.")
SearchQuerry = input("Please search for a wikipedia page.")
print(wikipedia.search(SearchQuerry))
selection = input("Please select one of the following options given to you ")
print(wikipedia.page(selection).url)
link = wikipedia.page(selection).url
newlink = link.replace("iki/", "/index.php?title=")
newlink = newlink + "&action=info"
print(newlink)
page = requests.get(newlink)

soup = BeautifulSoup(page.content, "html.parser")
#print(soup.prettify())
#table = soup.find_all(('table'))
rows = [soup.find("tr", id="mw-pageinfo-watchers"), soup.find("tr", id="mw-pageinfo-visiting-watchers"), soup.find("tr", id="mw-pvi-month-count"), soup.find("tr", id="mw-pageinfo-firsttime"), soup.find("tr", id="mw-pageinfo-lasttime"), soup.find("tr", id="mw-pageinfo-edits"), soup.find("tr", id="mw-pageinfo-recent-edits"), soup.find("tr", id="mw-pageinfo-recent-authors")]
rows_html = soup.find_all("tr")
for row in rows_html:
    row_data = []
    for cell in row.find_all("td"):
        row_data.append(cell.text)
    rows.append(row_data)
print(rows)
NumberOfPageWatchers = soup.find("tr", id="mw-pageinfo-watchers")
ActivePageWatchers = soup.find("tr", id="mw-pageinfo-visiting-watchers")
PageViews30Days = soup.find("tr", id="mw-pvi-month-count")
DateOfCreation = soup.find("tr", id="mw-pageinfo-firsttime")
DateOfLatestEdit = soup.find("tr", id="mw-pageinfo-lasttime")
NumberOfEdits = soup.find("tr", id="mw-pageinfo-edits")
NumberOfRecentEdits = soup.find("tr", id="mw-pageinfo-recent-edits")
RecentDistinctAuthors = soup.find("tr", id="mw-pageinfo-recent-authors")
print(NumberOfPageWatchers)
print(ActivePageWatchers)
print(PageViews30Days)
print(DateOfCreation)
print(DateOfLatestEdit)
print(NumberOfEdits)
print(NumberOfRecentEdits)
print(RecentDistinctAuthors)