import wikipedia
import datetime
from bs4 import BeautifulSoup
print("Hello, welcome to my Webscrapper.  This webscrapper utilizes wikipedia and can only gather data from wikipedia.")
SearchQuerry = input("Please search for a wikipedia page.")
print(wikipedia.search(SearchQuerry))
selection = input("Please select one of the following options given to you ")
print(wikipedia.page(selection).url)
link = wikipedia.page(selection).url
newlink = link.replace("iki/", "/index.php?title=")
newlink = newlink + "&action=info"
print(newlink)