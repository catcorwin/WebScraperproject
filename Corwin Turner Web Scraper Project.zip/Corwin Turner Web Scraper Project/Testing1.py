import wikipedia

searchQuerry = input("Please search for a topic on wikipedia ")
print(wikipedia.search(searchQuerry))
selection = input("Please select one of the following options given to you ")
print(wikipedia.page(selection).url)
link = wikipedia.page(selection).url
newlink = link.replace("iki/", "/index.php?title=")
print(newlink)
newlink = newlink + "&action=info"
print(newlink)