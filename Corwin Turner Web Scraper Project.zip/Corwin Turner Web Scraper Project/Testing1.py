#import wikipedia
#import datetime
import requests
from bs4 import BeautifulSoup
#print("Hello, welcome to my Webscrapper.  This webscrapper utilizes wikipedia and can only gather data from wikipedia.")
#SearchQuerry = input("Please search for a wikipedia page.")
#print(wikipedia.search(SearchQuerry))
#selection = input("Please select one of the following options given to you ")
#print(wikipedia.page(selection).url)
#link = wikipedia.page(selection).url
#newlink = link.replace("iki/", "/index.php?title=")
#newlink = newlink + "&action=info"
#print(newlink)
page = requests.get("https://en.wikipedia.org/w/index.php?title=USS_Wisconsin_(BB-64)&action=info")
soup = BeautifulSoup(page.content, "html.parser")
#print(soup.prettify())
table = soup.find_all(('table'))
rows = []
rows_html = soup.find_all("tr")
for row in rows_html:
    row_data = []
    for cell in row.find_all("td"):
        row_data.append(cell.text)
    rows.append(row_data)
print(rows[8])
print(rows[9])
print(rows[16])
print(rows[20])
print(rows[22])
print(rows[23])
print(rows[24])
print(rows[25])


